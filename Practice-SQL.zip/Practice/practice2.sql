--SET NOCOUNT ON;
--CREATE TABLE Employee
--(
--	EmployeeId	INT NOT NULL,
--	Firstname	VARCHAR(50) NOT NULL,
--	Lastname	VARCHAR(50) NOT NULL,
--	[Status]	BIT
--)

--INSERT INTO Employee VALUES (2, 'Apurva', 'Nashik', 1),(3, 'Apurva', 'Nashik', 1)

--DELETE FROM Employee

--INSERT INTO Employee 
--SELECT 1, 'Apurva', 'Nashik', 1
--UNION
--SELECT 2,'Apurva', 'NSK',1

--DROP TABLE Employee

ALTER TABLE Employee ADD City VARCHAR(50)

--first create allow null then alter to not null

SELECT * FROM Employee

--Assignment 2

--CREATE TABLE Hospital
--(
--	HospitalId INT NOT NULL,
--	HospitalName VARCHAR(50) NOT NULL,
--	HospitalAddress VARCHAR(100) NOT NULL,
--	HospitalContact VARCHAR(20) NOT NULL,
--	HospitalSpeciality VARCHAR(30) NOT NULL,
--	HospitalCapacity INT NOT NULL,
--	TotalWards INT NOT NULL,
--	TotalPhysicians INT NOT NULL
--)


