CREATE PROCEDURE [dbo].[GetEmployeeDetails] --PascalCase
	--@employeeId INT							--camelCase
AS
BEGIN
	SET NOCOUNT ON;

	SELECT	FirstName,
			LastName
	FROM	Employee1

END

EXECUTE GetEmployeeDetails 
---------------------------------------------------------------------
ALTER PROCEDURE [dbo].[GetEmployeeDetails] --PascalCase
	@employeeId INT	= 0				--Default		--camelCase
AS
BEGIN
	SET NOCOUNT ON;
	IF(@employeeId > 0)
		BEGIN
			SELECT	FirstName,
					LastName
			FROM	Employee1
			Where	Employee1Id = @employeeId
		END
	ELSE
		BEGIN
			SELECT	FirstName,
					LastName
			FROM	Employee1
		END
END
------------------------------------------------------------------
ALTER PROCEDURE [dbo].[GetEmployeeDetails] --PascalCase
	@employeeId INT	= 0						--camelCase
AS
BEGIN
	SET NOCOUNT ON;

	SELECT	FirstName,
			LastName
	FROM	Employee1
	WHERE	Employee1Id = IIF(@employeeId > 0, @employeeId, Employee1Id)
END

EXECUTE GetEmployeeDetails 2
----------------------------------------------------
ALTER PROCEDURE [dbo].[GetEmployeeDetails]
	@employeeId INT	= 0	
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE	emp
	SET		emp.Salary = 10
	FROM	Employee1 emp
	WHERE	Employee1Id = IIF(@employeeId > 0, @employeeId, Employee1Id)

	SELECT	FirstName,
			LastName,
			Salary
	FROM	Employee1
	WHERE	Employee1Id = IIF(@employeeId > 0, @employeeId, Employee1Id)
END
