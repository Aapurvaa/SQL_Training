--For instance, can write multiple queries
CREATE TABLE #Department
(
	DepartmentId INT,
	[Name]	VARCHAR(20)
)

SELECT * FROM #Department
------
SELECT	Salary,
		FirstName
INTO	#EmpTemp
FROM	Employee1

SELECT	* FROM #EmpTemp
------
DECLARE @EmpTemp1 AS TABLE
(
	EmpId INT
)

SELECT	* FROM @EmpTemp1

-- CTE Common Table Expression
-- Single statement
--nth high salary
;WITH CTE AS (SELECT	ROW_NUMBER() OVER (PARTITION BY CompanyId ORDER BY Salary DESC) AS RowNumber,		*FROM	Employee1)SELECT * FROM CTE WHERE RowNumber = 1;
--
SELECT C.[Name],
		E.firstname
FROM	Company as C INNER JOIN Emp1 AS E ON C. = E.CompId