DROP TABLE Company

CREATE TABLE Company (
	CompanyId	INT IDENTITY(1,	1) PRIMARY KEY NOT NULL,
	[Name]		VARCHAR(50),
	City		VARCHAR(50)
)

SELECT NEWID() --GUID security perpose

--ALT+F1 table history
--CTRL+ SHIFT + q

INSERT INTO Company([Name],City) VALUES('Apurva','Nashik')
INSERT INTO Company([Name],City) VALUES('Apurva','Nashik')
SELECT * FROM Company

CREATE TABLE Emp
(
	EmpId	INT IDENTITY(1	,1) PRIMARY KEY NOT NULL,
	[Name]	VARCHAR(50),
	Age		INT,
	CompanyId	INT FOREIGN KEY REFERENCES Company(CompanyId)
)

INSERT INTO Emp VALUES('Apurva',23,3)

SELECT * FROM Emp

--Dont use * , write column names
SELECT	ROW_NUMBER() OVER (ORDER BY[Name]) AS RN,
		--DISTINCT [Name],
		[Name],
		Age
		--CASE	WHEN Age >= 22
		--		THEN 1 
		--		ELSE 0 
		--END		AS CanMarried
FROM	Emp
--WHERE	Age > 21 OR CompanyId = 2
--WHERE Age BETWEEN 22 AND 25
WHERE Age IN (22, 23)
ORDER BY Age DESC
--Default ASC

EXEC('SELECT * FROM Emp')