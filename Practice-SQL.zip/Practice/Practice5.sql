CREATE TABLE Employee1
(
	Employee1Id	INT,
	FirstName	VARCHAR(50),
	LastName	VARCHAR(50),
	CompanyId	INT,
	Salary		DECIMAL(18, 2)
)
INSERT INTO Employee1 
VALUES  (1, 'Apurva', 'Jadhav', 1, 32000),
		(2, 'Krutika', 'Raval', 1, 40000),
		(3, 'Tanaya', 'Gavande', 2, 35000),
		(4, 'Aarti', 'Sangle', 2, 32000)

SELECT * FROM Employee1

--Group By
SELECT		CompanyId,
			COUNT(Employee1Id) AS TotalEmp
FROM		Employee1
GROUP BY	CompanyId

SELECT		FirstName, 
			LastName,
			COUNT(Employee1Id) AS TotalEmp
FROM		Employee1
GROUP BY	FirstName, LastName

SELECT		CompanyId,
			SUM(Salary) AS TotalSalary
FROM		Employee1
GROUP BY	CompanyId

--Group by with Having
SELECT		CompanyId,
			COUNT(Employee1Id) AS ToatlEmployee
FROM		Employee1
GROUP BY	CompanyId
HAVING		COUNT(Employee1Id) > 1

