CREATE FUNCTION [dbo].[GetSalaryIncrement]
(
	@salary			DECIMAL(18, 2),
	@performance	INT = 0
)
RETURNS	DECIMAL(18, 2)
AS
BEGIN
		DECLARE @rate DECIMAL(18, 2)

		SET @rate =  CASE
							WHEN @performance = 1 THEN 0.05
							WHEN @performance = 2 THEN 0.10
							WHEN @performance = 3 THEN 0.20
							WHEN @performance = 4 THEN 0.25
							WHEN @performance = 5 THEN 0.3
							ELSE 0
					END
		RETURN (@salary * @rate)
END

--SELECT [dbo].[GetSalaryIncrement](32000, 1)

ALTER PROCEDURE [dbo].[GetIncrement]
	@employeeId INT	= 0	,
	@performance INT = 1
AS
BEGIN
	SET NOCOUNT ON

	SELECT	FirstName,
			LastName,
			Salary,
			[dbo].[GetSalaryIncrement](Salary, @performance) AS Increment
	FROM	Employee1
	WHERE	Employee1Id = IIF(@employeeId > 0, @employeeId, Employee1Id)
END

EXECUTE GetIncrement 
