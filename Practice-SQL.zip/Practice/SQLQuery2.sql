CREATE VIEW EmployeeCompany
AS
SELECT	EMP.FirstName,
		EMP.LastName,
		EMP.Salary
FROM	Employee1 EMP
		INNER JOIN Company COM ON COM.CompanyId = EMP.CompanyId

SELECT * FROM EmployeeCompany

---Scalar Function - Retuen single value
CREATE FUNCTION [dbo].[CalculateEBill]
(
	@unit	INT,
	@rate	DECIMAL(18, 2)
)
RETURNS		DECIMAL(18, 2)
AS
BEGIN
	DECLARE @eBill DECIMAL(18, 2)
	SET @EBill = @unit * @rate
	RETURN @EBill	
END

SELECT [dbo].[CalculateEBill](1.2, 5.5) AS BILL

--TABLE VALUED FUNCTION-----return data in table type
CREATE FUNCTION [dbo].[GetCompanyData]
(
	@companyId	INT
)
RETURNS TABLE
AS
RETURN
	SELECT * FROM Company

SELECT * FROM [dbo].[GetCompanyData](1)
