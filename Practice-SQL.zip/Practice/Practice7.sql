-- join use for relational fields
CREATE TABLE Comp
(
	CompId		INT,
	[Name]		VARCHAR(20),
	City		VARCHAR(20)
)
INSERT INTO Comp VALUES (1, 'Aress', 'Nashik'),
						(2, 'Infosys','Pune')
CREATE TABLE Emp1
(
	Emp1Id		INT,
	CompId		INT,
	[Name]		VARCHAR(20)
)

INSERT INTO Emp1 VALUES (1, 1, 'Apurva'),
						(2, 2, 'krutika')

SELECT	EMP.Name AS Employee, 
		COM.Name AS Company
FROM	Emp1 AS EMP
		INNER JOIN Comp	AS COM ON EMP.CompId = COM.CompId

SELECT	EMP.Name AS Employee, 
		COM.Name AS Company
FROM	Emp1 AS EMP
		LEFT JOIN Comp	AS COM ON EMP.CompId = COM.CompId

SELECT	EMP.Name AS Employee, 
		COM.Name AS Company
FROM	Emp1 AS EMP
		LEFT JOIN Comp	AS COM ON EMP.CompId = COM.CompId