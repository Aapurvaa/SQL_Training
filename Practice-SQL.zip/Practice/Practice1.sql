--USE SQLTraining
DECLARE @Firstname VARCHAR(50) = 'Apurva';
PRINT @Firstname;

DECLARE @Score DECIMAL(18,2) = '78687678.669';
SELECT @Score as [Subject];

DECLARE @Date DATETIME = GETDATE();
SELECT @Date as Date;

SELECT TBL.[Subject],
		TBL.Score
FROM(
SELECT 'Physics' AS [Subject], 82 AS Score
UNION 
SELECT 'Maths' AS [Subject], 87 AS Score
) AS TBL

SELECT SUM(Score) / COUNT([Subject]) as Marks
FROM(
SELECT 'Physics' AS [Subject], 82 AS Score
UNION 
SELECT 'Maths' AS [Subject], 87 AS Score
) AS TBL


DECLARE @Date1 DATETIME = GETDATE()
SELECT CONVERT(VARCHAR(30), @Date1, 109)