SELECT CONCAT('Apurva',' Jadhav') AS MyName
SELECT FORMAT(2434357272.85847564, '#.###')
SELECT LOWER('APURVA')	--For Email for comparision
SELECT UPPER('APURVA')	
SELECT LEFT('APURVA', 5)
SELECT Right('APURVA', 5)
SELECT LEN('Apurva')
SELECT TRIM('    Apu')
SELECT CHARINDEX('J', 'Apurva Jadhav', 6)
SELECT REPLACE('Aress Software', 'Aress', 'TCS')
SELECT REVERSE('Nitin') --Security 
SELECT SUBSTRING('Aress Software', 1, 7)
