USE [master]
GO
/****** Object:  Database [Assignment5]    Script Date: 9/7/2023 11:14:15 AM ******/
CREATE DATABASE [Assignment5]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'Assignment5', FILENAME = N'C:\Users\apurva.jadhav\Assignment5.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'Assignment5_log', FILENAME = N'C:\Users\apurva.jadhav\Assignment5_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [Assignment5] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Assignment5].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [Assignment5] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [Assignment5] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [Assignment5] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [Assignment5] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [Assignment5] SET ARITHABORT OFF 
GO
ALTER DATABASE [Assignment5] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [Assignment5] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [Assignment5] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [Assignment5] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [Assignment5] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [Assignment5] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [Assignment5] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [Assignment5] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [Assignment5] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [Assignment5] SET  ENABLE_BROKER 
GO
ALTER DATABASE [Assignment5] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [Assignment5] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [Assignment5] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [Assignment5] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [Assignment5] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [Assignment5] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [Assignment5] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [Assignment5] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [Assignment5] SET  MULTI_USER 
GO
ALTER DATABASE [Assignment5] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [Assignment5] SET DB_CHAINING OFF 
GO
ALTER DATABASE [Assignment5] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [Assignment5] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [Assignment5] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [Assignment5] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [Assignment5] SET QUERY_STORE = OFF
GO
USE [Assignment5]
GO
/****** Object:  UserDefinedFunction [dbo].[CalculateDiscount]    Script Date: 9/7/2023 11:14:15 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--function to calculate discount
CREATE FUNCTION [dbo].[CalculateDiscount]
(
	@userId		INT,
	@discount	DECIMAL(18, 2)
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
	DECLARE @totalPrice INT 
	SET @totalPrice =		(SELECT	SUM( PRO.Price * ORD.Quantity)
							FROM	[Order] AS ORD LEFT JOIN Product AS [PRO] ON ORD.ProductId = PRO.ProductId
							WHERE	ORD.UserId = @userId)
	DECLARE @discountedPrice DECIMAL(18, 2)
	SET @discountedPrice = @totalPrice - (@totalPrice * (@discount / 100))
	RETURN @discountedPrice
END
GO
/****** Object:  Table [dbo].[Order]    Script Date: 9/7/2023 11:14:15 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Order](
	[OrderId] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NULL,
	[ProductId] [int] NULL,
	[Quantity] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[OrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Product]    Script Date: 9/7/2023 11:14:15 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Product](
	[ProductId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](20) NULL,
	[Price] [decimal](18, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[User]    Script Date: 9/7/2023 11:14:15 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NULL,
	[Contact] [varchar](20) NULL,
	[Address] [varchar](150) NULL,
	[Email] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Order] ON 
GO
INSERT [dbo].[Order] ([OrderId], [UserId], [ProductId], [Quantity]) VALUES (1, 1, 1, 2)
GO
INSERT [dbo].[Order] ([OrderId], [UserId], [ProductId], [Quantity]) VALUES (2, 1, 2, 4)
GO
INSERT [dbo].[Order] ([OrderId], [UserId], [ProductId], [Quantity]) VALUES (3, 1, 6, 3)
GO
INSERT [dbo].[Order] ([OrderId], [UserId], [ProductId], [Quantity]) VALUES (4, 2, 4, 8)
GO
INSERT [dbo].[Order] ([OrderId], [UserId], [ProductId], [Quantity]) VALUES (5, 2, 5, 2)
GO
INSERT [dbo].[Order] ([OrderId], [UserId], [ProductId], [Quantity]) VALUES (6, 3, 2, 4)
GO
INSERT [dbo].[Order] ([OrderId], [UserId], [ProductId], [Quantity]) VALUES (7, 3, 1, 3)
GO
INSERT [dbo].[Order] ([OrderId], [UserId], [ProductId], [Quantity]) VALUES (8, 3, 3, 10)
GO
INSERT [dbo].[Order] ([OrderId], [UserId], [ProductId], [Quantity]) VALUES (9, 4, 3, 2)
GO
INSERT [dbo].[Order] ([OrderId], [UserId], [ProductId], [Quantity]) VALUES (10, 5, 6, 3)
GO
SET IDENTITY_INSERT [dbo].[Order] OFF
GO
SET IDENTITY_INSERT [dbo].[Product] ON 
GO
INSERT [dbo].[Product] ([ProductId], [Name], [Price]) VALUES (1, N'Bread', CAST(60.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Product] ([ProductId], [Name], [Price]) VALUES (2, N'Coffee', CAST(30.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Product] ([ProductId], [Name], [Price]) VALUES (3, N'Milk', CAST(120.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Product] ([ProductId], [Name], [Price]) VALUES (4, N'Rice ', CAST(68.90 AS Decimal(18, 2)))
GO
INSERT [dbo].[Product] ([ProductId], [Name], [Price]) VALUES (5, N'ice cream', CAST(50.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Product] ([ProductId], [Name], [Price]) VALUES (6, N'juice', CAST(46.00 AS Decimal(18, 2)))
GO
SET IDENTITY_INSERT [dbo].[Product] OFF
GO
SET IDENTITY_INSERT [dbo].[User] ON 
GO
INSERT [dbo].[User] ([UserId], [Name], [Contact], [Address], [Email]) VALUES (1, N'Apurva Jadhav', N'9056432678', N'Enamdar Compound Datta Mandir Road Nr Jayant Oil Mills Bhandup , Mumbai,Nashik,400078,India', N'apurva.jadhav@gmail.com')
GO
INSERT [dbo].[User] ([UserId], [Name], [Contact], [Address], [Email]) VALUES (2, N'Tanaya gavande', N'7083695678', N'317  Samuel Street Mandvi, Mumbai,Nashik,400003,India', N'tanaya.gavande@gmail.com')
GO
INSERT [dbo].[User] ([UserId], [Name], [Contact], [Address], [Email]) VALUES (3, N'Rutuja Harale', N'8075432789', N'Shop No 220 Fashqua Shopping Centre Opp Super Bazar Stn Road Santacruz, Mumbai,Nashik,400054,India', N'rutuja.harale@gmail.com')
GO
INSERT [dbo].[User] ([UserId], [Name], [Contact], [Address], [Email]) VALUES (4, N'Krutika Rawal', N'9529878533', N'Galan No 717 Prasd Chambers Tata Rd No 2 Girgaon, Mumbai,Nashik,400004,India', N'krutika.rawal@gmail.com')
GO
INSERT [dbo].[User] ([UserId], [Name], [Contact], [Address], [Email]) VALUES (5, N'Aarti Sangle', N'7865498328', N'25 --/ R P Road, Hyderabad,Nashik,500003,India', N'aarti.sangle@gmail.com')
GO
INSERT [dbo].[User] ([UserId], [Name], [Contact], [Address], [Email]) VALUES (6, N'Snahal Jagtap', N'8788569086', N'57  Yusuf Bldg Veer Nariman Rd Above Akbarallys Fort, Mumbai,Nashik,400023,India', N'snehal.jagtap@gmail.com')
GO
SET IDENTITY_INSERT [dbo].[User] OFF
GO
ALTER TABLE [dbo].[Order]  WITH CHECK ADD  CONSTRAINT [ProductId] FOREIGN KEY([ProductId])
REFERENCES [dbo].[Product] ([ProductId])
GO
ALTER TABLE [dbo].[Order] CHECK CONSTRAINT [ProductId]
GO
ALTER TABLE [dbo].[Order]  WITH CHECK ADD  CONSTRAINT [UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
ALTER TABLE [dbo].[Order] CHECK CONSTRAINT [UserId]
GO
/****** Object:  StoredProcedure [dbo].[GetUserDetails]    Script Date: 9/7/2023 11:14:15 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[GetUserDetails]	
	@case	INT = 1,
	@userId INT	= 0
AS
BEGIN
	SET NOCOUNT ON;

	IF (@case = 1)
		BEGIN
			SELECT	[USE].[Name],
					[PRO].[Name]
			FROM	[Order] AS ORD LEFT JOIN [User] AS [USE]  ON ORD.UserId = [USE].UserId
			LEFT JOIN Product AS PRO ON ORD.ProductId = PRO.ProductId
			WHERE	[USE].UserId = IIF(@userId > 0, @userId, [USE].UserId)
		END
	ELSE IF(@case = 2)
		BEGIN
			DECLARE @totalPrice DECIMAL(18, 2) 
			SET @totalPrice =	(SELECT	SUM( PRO.Price * ORD.Quantity)
								FROM	[Order] AS ORD LEFT JOIN Product AS [PRO] ON ORD.ProductId = PRO.ProductId
								WHERE	ORD.UserId = @userId)

			DECLARE @discountRate INT
			SET @discountRate = 30
			
			SELECT	[USE].[Name] AS UserName,
					@totalPrice AS TotalPrice,
					@totalPrice - [dbo].[CalculateDiscount](@userId, @discountRate)  AS Discount,
					[dbo].[CalculateDiscount](@userId, @discountRate) AS DiscountAmount
			FROM	[User] AS [USE]
			WHERE	[USE].UserId = IIF(@userId > 0, @userId, [USE].UserId)
			
		END
END
GO
USE [master]
GO
ALTER DATABASE [Assignment5] SET  READ_WRITE 
GO
