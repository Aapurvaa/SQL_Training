DROP TABLE IF EXISTS [Order], Product, [User]
--Create table User
CREATE TABLE [User]
(
	UserId		INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	[Name]		VARCHAR(50),
	Contact		VARCHAR(20),
	[Address]	VARCHAR(150),
	Email		VARCHAR(50)
)
INSERT INTO [User] VALUES ('Apurva Jadhav', '9056432678', 'Enamdar Compound Datta Mandir Road Nr Jayant Oil Mills Bhandup , Mumbai,Nashik,400078,India', 'apurva.jadhav@gmail.com'),
						  ('Tanaya gavande', '7083695678', '317  Samuel Street Mandvi, Mumbai,Nashik,400003,India', 'tanaya.gavande@gmail.com'),
						  ('Rutuja Harale', '8075432789', 'Shop No 220 Fashqua Shopping Centre Opp Super Bazar Stn Road Santacruz, Mumbai,Nashik,400054,India', 'rutuja.harale@gmail.com'),
						  ('Krutika Rawal', '9529878533', 'Galan No 717 Prasd Chambers Tata Rd No 2 Girgaon, Mumbai,Nashik,400004,India', 'krutika.rawal@gmail.com'),
						  ('Aarti Sangle', '7865498328', '25 --/ R P Road, Hyderabad,Nashik,500003,India', 'aarti.sangle@gmail.com'),
						  ('Snahal Jagtap', '8788569086', '57  Yusuf Bldg Veer Nariman Rd Above Akbarallys Fort, Mumbai,Nashik,400023,India', 'snehal.jagtap@gmail.com')
SELECT	[Name],
		Contact,
		[Address],
		Email
FROM	[User]
--Create table Product
CREATE TABLE Product
(
	ProductId	INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	[Name]		VARCHAR(20),
	Price		DECIMAL(18, 2)
)
INSERT INTO Product VALUES ('Bread', 60),
						   ('Coffee', 30),
						   ('Milk', 120),
						   ('Rice ', 68.9),
						   ('ice cream', 50),
						   ('juice', 46)
SELECT	[Name],
		Price
FROM	Product
--Create table Order
CREATE TABLE [Order]
(
	OrderId		INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	UserId		INT,
	CONSTRAINT	UserId FOREIGN KEY (UserId)
    REFERENCES	[User](UserId),
	ProductId	INT,
	CONSTRAINT	ProductId FOREIGN KEY (ProductId)
    REFERENCES	Product(ProductId),
	Quantity	INT,
)
INSERT INTO [Order] VALUES (1,1,2),
						   (1,2,4),
						   (1,6,3),
						   (2,4,8),
						   (2,5,2),
						   (3,2,4),
						   (3,1,3),
						   (3,3,10),
						   (4,3,2),
						   (5,6,3)
SELECT	UserId,
		ProductId,
		Quantity
FROM	[Order]
--function to calculate discount
CREATE FUNCTION [dbo].[CalculateDiscount]
(
	@userId		INT,
	@discount	DECIMAL(18, 2)
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
	DECLARE @totalPrice INT 
	SET @totalPrice =		(SELECT	SUM( PRO.Price * ORD.Quantity)
							FROM	[Order] AS ORD LEFT JOIN Product AS [PRO] ON ORD.ProductId = PRO.ProductId
							WHERE	ORD.UserId = @userId)
	DECLARE @discountedPrice DECIMAL(18, 2)
	SET @discountedPrice = @totalPrice - (@totalPrice * (@discount / 100))
	RETURN @discountedPrice
END

--procedure to show details
CREATE PROCEDURE [dbo].[GetUserDetails]	
	@case	INT = 1,
	@userId INT	= 0
AS
BEGIN
	SET NOCOUNT ON;

	IF (@case = 1)
		BEGIN
			SELECT	[USE].[Name],
					[PRO].[Name]
			FROM	[Order] AS ORD LEFT JOIN [User] AS [USE]  ON ORD.UserId = [USE].UserId
			LEFT JOIN Product AS PRO ON ORD.ProductId = PRO.ProductId
			WHERE	[USE].UserId = IIF(@userId > 0, @userId, [USE].UserId)
		END
	ELSE IF(@case = 2)
		BEGIN
			DECLARE @totalPrice DECIMAL(18, 2) 
			SET @totalPrice =	(SELECT	SUM( PRO.Price * ORD.Quantity)
								FROM	[Order] AS ORD LEFT JOIN Product AS [PRO] ON ORD.ProductId = PRO.ProductId
								WHERE	ORD.UserId = @userId)

			DECLARE @discountRate INT
			SET @discountRate = 30
			
			SELECT	[USE].[Name] AS UserName,
					@totalPrice AS TotalPrice,
					@totalPrice - [dbo].[CalculateDiscount](@userId, @discountRate)  AS Discount,
					[dbo].[CalculateDiscount](@userId, @discountRate) AS DiscountAmount
			FROM	[User] AS [USE]
			WHERE	[USE].UserId = IIF(@userId > 0, @userId, [USE].UserId)
			
		END
END

EXECUTE GetUserDetails 1
EXECUTE GetUserDetails 2,1

			
