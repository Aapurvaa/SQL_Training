USE [master]
GO
/****** Object:  Database [FinalAssignment]    Script Date: 9/7/2023 7:10:23 PM ******/
CREATE DATABASE [FinalAssignment]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'FinalAssignment', FILENAME = N'C:\Users\apurva.jadhav\FinalAssignment.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'FinalAssignment_log', FILENAME = N'C:\Users\apurva.jadhav\FinalAssignment_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [FinalAssignment] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [FinalAssignment].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [FinalAssignment] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [FinalAssignment] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [FinalAssignment] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [FinalAssignment] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [FinalAssignment] SET ARITHABORT OFF 
GO
ALTER DATABASE [FinalAssignment] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [FinalAssignment] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [FinalAssignment] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [FinalAssignment] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [FinalAssignment] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [FinalAssignment] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [FinalAssignment] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [FinalAssignment] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [FinalAssignment] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [FinalAssignment] SET  ENABLE_BROKER 
GO
ALTER DATABASE [FinalAssignment] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [FinalAssignment] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [FinalAssignment] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [FinalAssignment] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [FinalAssignment] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [FinalAssignment] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [FinalAssignment] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [FinalAssignment] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [FinalAssignment] SET  MULTI_USER 
GO
ALTER DATABASE [FinalAssignment] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [FinalAssignment] SET DB_CHAINING OFF 
GO
ALTER DATABASE [FinalAssignment] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [FinalAssignment] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [FinalAssignment] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [FinalAssignment] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [FinalAssignment] SET QUERY_STORE = OFF
GO
USE [FinalAssignment]
GO
/****** Object:  UserDefinedFunction [dbo].[CalculateDeduction]    Script Date: 9/7/2023 7:10:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[CalculateDeduction]
(
	@userId		INT = 0
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
	DECLARE @gross DECIMAL(18, 2)
	SET @gross = (SELECT GrossAmount FROM Salary
				  WHERE EmployeeId = @userId)

	DECLARE @pf DECIMAL(18, 2)
	SET @pf = (SELECT payc.DeductionRate FROM PaymentCode AS payc INNER JOIN Payslip AS pays 
			   ON payc.PaymentCodeId = pays.PaymentCodeId
			   WHERE pays.PaymentCodeId = payc.PaymentCodeId AND pays.UserId = @userId AND payc.PaymentCode = 'PF')

	DECLARE @pension DECIMAL(18, 2)
	SET @pension = (SELECT payc.DeductionRate FROM PaymentCode AS payc INNER JOIN Payslip AS pays 
			   ON payc.PaymentCodeId = pays.PaymentCodeId
			   WHERE pays.PaymentCodeId = payc.PaymentCodeId AND pays.UserId = @userId AND payc.PaymentCode = 'PENSION')
	
	DECLARE @basicpay DECIMAL(18, 2)
	SET @basicpay = (SELECT payc.DeductionRate FROM PaymentCode AS payc INNER JOIN Payslip AS pays 
					 ON payc.PaymentCodeId = pays.PaymentCodeId
					 WHERE pays.PaymentCodeId = payc.PaymentCodeId AND pays.UserId = @userId AND payc.PaymentCode = 'BASICPAY')

	DECLARE @totalDeduction DECIMAL(18, 2)
	SET @totalDeduction = (@gross * (@pf / 100)) + (@gross * (@pension / 100) + (@gross * (@basicpay / 100))) 
	RETURN @totalDeduction
END
GO
/****** Object:  UserDefinedFunction [dbo].[CalculateNetSalary]    Script Date: 9/7/2023 7:10:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[CalculateNetSalary]
(
	@userId		INT
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
	DECLARE @gross DECIMAL(18, 2)
	SET @gross = (SELECT GrossAmount FROM Salary
				  WHERE EmployeeId = @userId)
	DECLARE @totalDeduction DECIMAL(18, 2)
	SET @totalDeduction = (@gross * (7.2 / 100)) + (@gross * (3.9 / 100))
	RETURN (@gross - @totalDeduction)
END
GO
/****** Object:  Table [dbo].[PaymentCode]    Script Date: 9/7/2023 7:10:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PaymentCode](
	[PaymentCodeId] [int] IDENTITY(1,1) NOT NULL,
	[PaymentCode] [varchar](20) NOT NULL,
	[DeductionRate] [decimal](18, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[PaymentCodeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Payslip]    Script Date: 9/7/2023 7:10:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Payslip](
	[PayslipId] [int] IDENTITY(1,1) NOT NULL,
	[PaymentCodeId] [int] NULL,
	[UserId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[PayslipId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Pharmacy]    Script Date: 9/7/2023 7:10:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Pharmacy](
	[PharmacyId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NULL,
	[Code] [varchar](20) NULL,
	[City] [varchar](20) NULL,
	[CreatedDate] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[PharmacyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Salary]    Script Date: 9/7/2023 7:10:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Salary](
	[SalaryId] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeId] [int] NULL,
	[GrossAmount] [decimal](18, 2) NULL,
	[Deduction] [decimal](18, 2) NULL,
	[NetAmount] [decimal](18, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[SalaryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[User]    Script Date: 9/7/2023 7:10:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](20) NULL,
	[LastName] [varchar](20) NULL,
	[DateOfBirth] [date] NULL,
	[Role] [varchar](20) NULL,
	[CreatedDate] [date] NULL,
	[PharmacyId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[PaymentCode] ON 
GO
INSERT [dbo].[PaymentCode] ([PaymentCodeId], [PaymentCode], [DeductionRate]) VALUES (1, N'BASICPAY', CAST(0.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[PaymentCode] ([PaymentCodeId], [PaymentCode], [DeductionRate]) VALUES (2, N'PF', CAST(7.20 AS Decimal(18, 2)))
GO
INSERT [dbo].[PaymentCode] ([PaymentCodeId], [PaymentCode], [DeductionRate]) VALUES (3, N'PENSION', CAST(3.90 AS Decimal(18, 2)))
GO
SET IDENTITY_INSERT [dbo].[PaymentCode] OFF
GO
SET IDENTITY_INSERT [dbo].[Payslip] ON 
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (1, 1, 1)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (2, 2, 1)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (3, 3, 1)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (4, 1, 2)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (5, 2, 2)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (6, 3, 2)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (7, 1, 3)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (8, 2, 3)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (9, 3, 3)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (10, 1, 4)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (11, 2, 4)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (12, 3, 4)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (13, 1, 5)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (14, 2, 5)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (15, 3, 5)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (16, 1, 6)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (17, 2, 6)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (18, 3, 6)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (19, 1, 7)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (20, 2, 7)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (21, 3, 7)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (22, 1, 8)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (23, 2, 8)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (24, 3, 8)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (25, 1, 9)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (26, 2, 9)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (27, 3, 9)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (28, 1, 10)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (29, 2, 10)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (30, 3, 10)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (31, 1, 11)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (32, 2, 11)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (33, 3, 11)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (34, 1, 12)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (35, 2, 12)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (36, 3, 12)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (37, 1, 13)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (38, 2, 13)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (39, 3, 13)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (40, 1, 14)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (41, 2, 14)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (42, 3, 14)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (43, 1, 15)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (44, 2, 15)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (45, 3, 15)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (46, 1, 16)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (47, 2, 16)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (48, 3, 16)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (49, 1, 17)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (50, 2, 17)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (51, 3, 17)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (52, 1, 18)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (53, 2, 18)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [UserId]) VALUES (54, 3, 18)
GO
SET IDENTITY_INSERT [dbo].[Payslip] OFF
GO
SET IDENTITY_INSERT [dbo].[Pharmacy] ON 
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (1, N'Vista pharmacy', N'101', N'Nashik', CAST(N'2000-04-17' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (2, N'Arrow Pharmacy', N'203', N'Pune', CAST(N'2001-03-27' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (3, N'Dakota pharmacy', N'456', N'Chennai', CAST(N'2000-09-03' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (4, N'Pacific pharmacy', N'231', N'Mumbai', CAST(N'2007-07-12' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (5, N'Pharmacy Alliance', N'211', N'Nashik', CAST(N'2003-11-15' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (6, N'Concord Pharmacy', N'566', N'Pune', CAST(N'2000-11-27' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (7, N'Union Center Pharmacy', N'321', N'Pune', CAST(N'2002-10-07' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (8, N'Holloway Pharmacy', N'135', N'Pune', CAST(N'2000-09-07' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (9, N'Pharma best', N'432', N'Chennai', CAST(N'2008-09-04' AS Date))
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (10, N'Pharmacy Express', N'356', N'Chennai', CAST(N'2009-03-07' AS Date))
GO
SET IDENTITY_INSERT [dbo].[Pharmacy] OFF
GO
SET IDENTITY_INSERT [dbo].[Salary] ON 
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (1, 1, CAST(350000.00 AS Decimal(18, 2)), CAST(38850.00 AS Decimal(18, 2)), CAST(311150.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (2, 2, CAST(320000.00 AS Decimal(18, 2)), CAST(35520.00 AS Decimal(18, 2)), CAST(284480.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (3, 3, CAST(325000.00 AS Decimal(18, 2)), CAST(36075.00 AS Decimal(18, 2)), CAST(288925.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (4, 4, CAST(360000.00 AS Decimal(18, 2)), CAST(39960.00 AS Decimal(18, 2)), CAST(320040.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (5, 5, CAST(330000.00 AS Decimal(18, 2)), CAST(36630.00 AS Decimal(18, 2)), CAST(293370.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (6, 6, CAST(325000.00 AS Decimal(18, 2)), CAST(36075.00 AS Decimal(18, 2)), CAST(288925.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (7, 7, CAST(360000.00 AS Decimal(18, 2)), CAST(39960.00 AS Decimal(18, 2)), CAST(320040.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (8, 8, CAST(325000.00 AS Decimal(18, 2)), CAST(36075.00 AS Decimal(18, 2)), CAST(288925.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (9, 9, CAST(326000.00 AS Decimal(18, 2)), CAST(36186.00 AS Decimal(18, 2)), CAST(289814.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (10, 10, CAST(365000.00 AS Decimal(18, 2)), CAST(40515.00 AS Decimal(18, 2)), CAST(324485.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (11, 11, CAST(340000.00 AS Decimal(18, 2)), CAST(37740.00 AS Decimal(18, 2)), CAST(302260.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (12, 12, CAST(342000.00 AS Decimal(18, 2)), CAST(37962.00 AS Decimal(18, 2)), CAST(304038.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (13, 13, CAST(370000.00 AS Decimal(18, 2)), CAST(41070.00 AS Decimal(18, 2)), CAST(328930.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (14, 14, CAST(325000.00 AS Decimal(18, 2)), CAST(36075.00 AS Decimal(18, 2)), CAST(288925.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (15, 15, CAST(320000.00 AS Decimal(18, 2)), CAST(35520.00 AS Decimal(18, 2)), CAST(284480.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (16, 16, CAST(400000.00 AS Decimal(18, 2)), CAST(44400.00 AS Decimal(18, 2)), CAST(355600.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (17, 17, CAST(370000.00 AS Decimal(18, 2)), CAST(41070.00 AS Decimal(18, 2)), CAST(328930.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount]) VALUES (18, 18, CAST(350000.00 AS Decimal(18, 2)), CAST(38850.00 AS Decimal(18, 2)), CAST(311150.00 AS Decimal(18, 2)))
GO
SET IDENTITY_INSERT [dbo].[Salary] OFF
GO
SET IDENTITY_INSERT [dbo].[User] ON 
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (1, N'Parker', N'Smith', CAST(N'1999-06-28' AS Date), N'Manager', CAST(N'2018-10-03' AS Date), 1)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (2, N'River', N'Johnson', CAST(N'1997-09-18' AS Date), N'Employee', CAST(N'2019-09-07' AS Date), 1)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (3, N'Rowan', N'Williams', CAST(N'1996-08-16' AS Date), N'Employee', CAST(N'2019-11-21' AS Date), 1)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (4, N'Riley', N'Johnson', CAST(N'1999-09-10' AS Date), N'Manager', CAST(N'2017-09-11' AS Date), 2)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (5, N'Avery', N'Brown', CAST(N'1994-03-26' AS Date), N'Employee', CAST(N'2020-12-12' AS Date), 2)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (6, N'Logan ', N'Smith', CAST(N'1994-03-20' AS Date), N'Employee', CAST(N'2021-09-23' AS Date), 2)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (7, N'Quinn', N'Jones', CAST(N'1999-09-03' AS Date), N'Manager', CAST(N'2018-09-05' AS Date), 3)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (8, N'Jordan', N'Garcia', CAST(N'2000-05-03' AS Date), N'Employee', CAST(N'2020-04-04' AS Date), 3)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (9, N'Cameron', N'Johnson', CAST(N'1993-09-13' AS Date), N'Employee', CAST(N'2021-06-05' AS Date), 3)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (10, N'Angel', N'Smith', CAST(N'2000-09-03' AS Date), N'Manager', CAST(N'2022-09-03' AS Date), 4)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (11, N'Carter', N'Miller', CAST(N'1999-04-30' AS Date), N'Employee', CAST(N'2021-09-06' AS Date), 4)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (12, N'Ryan', N'Johnson', CAST(N'2000-04-12' AS Date), N'Employee', CAST(N'2020-11-07' AS Date), 4)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (13, N'Dylan ', N'Davis', CAST(N'2000-09-03' AS Date), N'Manager', CAST(N'2020-09-08' AS Date), 5)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (14, N'Noah', N'Brown', CAST(N'1994-10-05' AS Date), N'Employee', CAST(N'2021-11-03' AS Date), 5)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (15, N'Ezra', N'Smith', CAST(N'2000-09-03' AS Date), N'Employee', CAST(N'2018-09-07' AS Date), 5)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (16, N'Emery', N'Davis', CAST(N'2000-11-02' AS Date), N'Manager', CAST(N'2019-03-03' AS Date), 6)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (17, N'Hunter', N'Johnson', CAST(N'1999-11-03' AS Date), N'Employee', CAST(N'2020-09-04' AS Date), 6)
GO
INSERT [dbo].[User] ([UserId], [FirstName], [LastName], [DateOfBirth], [Role], [CreatedDate], [PharmacyId]) VALUES (18, N'August', N'Smith', CAST(N'2000-10-12' AS Date), N'Employee', CAST(N'2021-06-07' AS Date), 6)
GO
SET IDENTITY_INSERT [dbo].[User] OFF
GO
ALTER TABLE [dbo].[Payslip]  WITH CHECK ADD  CONSTRAINT [PaymentCodeId] FOREIGN KEY([PaymentCodeId])
REFERENCES [dbo].[PaymentCode] ([PaymentCodeId])
GO
ALTER TABLE [dbo].[Payslip] CHECK CONSTRAINT [PaymentCodeId]
GO
ALTER TABLE [dbo].[Payslip]  WITH CHECK ADD  CONSTRAINT [UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
ALTER TABLE [dbo].[Payslip] CHECK CONSTRAINT [UserId]
GO
ALTER TABLE [dbo].[Salary]  WITH CHECK ADD  CONSTRAINT [EmployeeId] FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[User] ([UserId])
GO
ALTER TABLE [dbo].[Salary] CHECK CONSTRAINT [EmployeeId]
GO
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [PharmacyId] FOREIGN KEY([PharmacyId])
REFERENCES [dbo].[Pharmacy] ([PharmacyId])
GO
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [PharmacyId]
GO
/****** Object:  StoredProcedure [dbo].[GetUserDetails]    Script Date: 9/7/2023 7:10:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[GetUserDetails]	
	@case	INT = 1
AS
BEGIN
	IF (@case = 1)
		BEGIN
			UPDATE	Salary
			SET		Deduction = (SELECT [dbo].[CalculateDeduction](EmployeeId)),
					NetAmount = GrossAmount - (SELECT [dbo].[CalculateDeduction](EmployeeId))
			WHERE	EmployeeId = EmployeeId 
			SELECT  EmployeeId,
					GrossAmount,
					Deduction,
					NetAmount
			FROM	Salary 
		END
	ELSE IF (@case = 2)
		BEGIN
			SELECT	[USE].Firstname AS UserName,
					[USE].[Role],
					PayC.PaymentCode
			FROM	Payslip AS PayS LEFT JOIN  PaymentCode AS PayC ON PayS.PaymentCodeId = PayC.PaymentCodeId
					LEFT JOIN [User] AS [USE] ON PayS.UserId = [USE].UserId
			WHERE	[USE].Role = 'Employee' AND [PayC].PaymentCode = 'BASICPAY'
		END
	ELSE IF (@case = 3)
		BEGIN
			SELECT		PHA.[Name] AS Pharmacy,
						MAX(SAL.NetAmount) AS HighestSalary
			FROM		[User] AS [USE] INNER JOIN Pharmacy AS PHA ON [USE].PharmacyId = PHA.PharmacyId 
						INNER JOIN Salary AS SAL ON [USE].UserId = SAL.EmployeeId
			WHERE		[USE].[Role] = 'Employee'
			GROUP BY	PHA.[Name]
		END	
END
GO
USE [master]
GO
ALTER DATABASE [FinalAssignment] SET  READ_WRITE 
GO
