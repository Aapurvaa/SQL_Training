--drop tables if exists any
DROP TABLE IF EXISTS Student, Teacher, Department;
DROP TABLE IF EXISTS Appointment, Hospital, Patient
--create table Department
CREATE TABLE Department
(
	DepartmentId	INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	[Name]			VARCHAR(50) NOT NULL,
	Contact			VARCHAR(20) NOT NULL,
	HOD				VARCHAR(50) NOT NULL,
	Capacity		INT			NOT NULL,
	Building		VARCHAR(20) NOT NULL
)
INSERT INTO Department VALUES('Computer Department', '+91-020-2562357', 'Dr. D. V. Medhane', 180, 'A-Building'),
							 ('IT Department', '+91-020-2562358', 'Dr. C. V. Jadhav', 90, 'A-Building'),
							 ('Mechanical Department', '+91-021-2574558', 'Dr. A. A. Andhare', 180, 'C-Building'),
							 ('Civil Department', '+91-021-2574554', 'Dr. P. M. Atre', 180, 'B-Building'),
							 ('ENTC Department', '+91-021-3454554', 'Dr. C. S. Patil', 90, 'C-Building' )
SELECT	[Name],
		Contact,
		HOD	,
		Capacity,
		Building
FROM	Department
--create table Teacher
CREATE TABLE Teacher
(
	TeacherId		INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	[Name]			VARCHAR(20) NOT NULL,
	Age				INT			NOT NULL,
	Gender			VARCHAR(20) NOT NULL,
	DateOfJoin		Date		NOT NULL,
	Contact			VARCHAR(20) NOT NULL,
	Salary			INT			NOT NULL,
	DepartmentId	INT			NOT NULL,
	CONSTRAINT		DepartmentId FOREIGN KEY (DepartmentId)
    REFERENCES		Department(DepartmentId)
)
INSERT INTO Teacher VALUES('Mr. G. H. Adke', 32, 'Male', '2000-09-04', '7209538976', 50000, 1),
						  ('Mrs. J. P. Patil', 30, 'Female', '2001-08-02', '9523558916', 45000, 4),
						  ('Mr. S. S. Gholap', 45, 'Male', '2001-09-02', '9422780969', 30000, 2),
						  ('Mrs. R. R. Shewale', 35, 'Female', '2000-02-02', '9529876544', 40000, 3),
						  ('Dr. D. V. Madhane', 36, 'Male', '1998-03-15', '9622875543', 100000, 1)
SELECT	Teacher.[Name],
		Teacher.Age,
		Teacher.Gender,
		Teacher.DateOfJoin,
		Teacher.Contact,
		Teacher.Salary,
		Department.[Name] AS Department
FROM	Teacher,Department
WHERE	Teacher.DepartmentId = Department.DepartmentId
--crete table Student
CREATE TABLE Student
(
	StudentId		INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	[Name]			VARCHAR(50) NOT NULL,
	Age				INT			NOT NULL,
	Gender			VARCHAR(20) NOT NULL,
	Contact			VARCHAR(20) NOT NULL,
	DepartmentId	INT			NOT NULL,
	TeacherId		INT			NOT NULL, 
	CONSTRAINT		Dept FOREIGN KEY (DepartmentId)
    REFERENCES		Department(DepartmentId),
	CONSTRAINT		Mentor FOREIGN KEY (TeacherId)
    REFERENCES		Teacher(TeacherId)	
)
INSERT INTO Student VALUES('Apurva Jadhav', 21, 'Female', '7822289764', 1, 1),
						  ('Tanaya Gavande', 21, 'Female', '7239876544', 1, 5),
						  ('Rutuja Harale', 22, 'Female', '7289435788', 3, 4),
						  ('Krutika Rawal', 21, 'Female', '9522314467', 2, 3),
						  ('Aarti Sangle', 22, 'Female', '9522876459', 4, 2),
						  ('Piyush Atre', 20, 'Male', '9588965423', 4, 2),
						  ('Akshay Andhare', 22, 'Male', '8852796544', 1, 1)
SELECT	Student.[Name],
		Student.Age,
		Student.Gender,
		Student.Contact,
		Department.[Name] As Department,
		Teacher.[Name] AS Mentor
FROM	Student,Teacher,Department
WHERE	Student.TeacherId = Teacher.TeacherId 
		AND 
		Student.DepartmentId = Department.DepartmentId
--use of keywords
SELECT	 ROW_NUMBER() OVER (ORDER BY[Name]) AS RowNumber,
		 TeacherId	AS Mentor,
	     [Name],
		 Age,
		 CASE	 WHEN Age >= 22
				 THEN 1 
				 ELSE 0 
		 END	 AS CanMarried
FROM	 Student
WHERE	 Age > 21 
		 OR 
		 DepartmentId = 1 
		 AND 
		 Age BETWEEN 22 AND 25 
		 OR 
		 TeacherId IN (1, 2, 5)
ORDER BY Age DESC

--use of pre-defined functions
SELECT CONCAT('Apurva',' Jadhav') AS MyName
SELECT FORMAT(2434357272.85847564, '#.###') AS Number
SELECT FORMAT(20230904, '####-##-##') AS [Date]
SELECT LOWER('APURVA@GMAIL.COM') AS Gmail
SELECT LEFT('APURVA', 5) AS [Left]
SELECT LEN('Apurva') AS [Length]
SELECT TRIM('    Apurva') AS [Trim]
SELECT CHARINDEX('J', 'Apurva Jadhav', 6) AS [Index]
SELECT REPLACE('Aress Software', 'Aress', 'TCS') AS [Replace]
SELECT REVERSE('Nitin') AS [Reverse]
SELECT SUBSTRING('Aress Software', 1, 7) AS [Substring]

