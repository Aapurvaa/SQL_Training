DROP TABLE IF EXISTS Salary, Payslip, PaymentCode, [User], Pharmacy

--Table Pharmacy
CREATE TABLE Pharmacy
(
	PharmacyId		INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	[Name]			VARCHAR(50),
	Code			VARCHAR(20),
	City			VARCHAR(20),
	CreatedDate		DATE
)
INSERT INTO Pharmacy VALUES ('Vista pharmacy', 101, 'Nashik', '2000-04-17'),
							('Arrow Pharmacy', 203, 'Pune', '2001-03-27'),
							('Dakota pharmacy', 456, 'Chennai', '2000-09-03'),
							('Pacific pharmacy', 231, 'Mumbai', '2007-07-12'),
							('Pharmacy Alliance', 211, 'Nashik', '2003-11-15'),
							('Concord Pharmacy', 566, 'Pune', '2000-11-27'),
							('Union Center Pharmacy', 321, 'Pune', '2002-10-07'),
							('Holloway Pharmacy', 135, 'Pune', '2000-09-07'),
							('Pharma best', 432, 'Chennai', '2008-09-04'),
							('Pharmacy Express', 356, 'Chennai', '2009-03-07')
SELECT		[Name],
			Code,
			City,
			CreatedDate
FROM		Pharmacy

--Table User
CREATE TABLE [User]
(
	UserId			INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	FirstName		VARCHAR(20),
	LastName		VARCHAR(20),
	DateOfBirth		DATE,
	[Role]			VARCHAR(20),
	CreatedDate		DATE,
	PharmacyId		INT,
	CONSTRAINT		PharmacyId FOREIGN KEY (PharmacyId)
    REFERENCES		Pharmacy (PharmacyId),
) 
INSERT INTO [User] VALUES ('Parker', 'Smith','1999-06-28','Manager','2018-10-03',1),
						  ('River', 'Johnson', '1997-09-18', 'Employee','2019-09-07',1),
						  ('Rowan', 'Williams', '1996-08-16', 'Employee','2019-11-21',1 ),
						  ('Riley', 'Johnson', '1999-09-10', 'Manager','2017-09-11',2),
						  ('Avery', 'Brown', '1994-03-26', 'Employee', '2020-12-12',2),
						  ('Logan ','Smith', '1994-03-20', 'Employee','2021-09-23',2),
						  ('Quinn', 'Jones', '1999-09-03','Manager','2018-09-05',3),
						  ('Jordan', 'Garcia', '2000-05-03', 'Employee','2020-04-04',3),
						  ('Cameron','Johnson', '1993-09-13','Employee','2021-06-05',3),
						  ('Angel','Smith', '2000-09-03', 'Manager','2022-09-03',4 ),
						  ('Carter', 'Miller', '1999-04-30', 'Employee', '2021-09-06', 4),
						  ('Ryan','Johnson', '2000-04-12', 'Employee', '2020-11-07', 4),
						  ('Dylan ', 'Davis', '2000-09-03', 'Manager', '2020-09-08', 5),
						  ('Noah', 'Brown', '1994-10-05', 'Employee','2021-11-03',5),
						  ('Ezra','Smith', '2000-09-03', 'Employee', '2018-09-07', 5),
						  ('Emery', 'Davis', '2000-11-02', 'Manager', '2019-03-03', 6),
						  ('Hunter','Johnson', '1999-11-03', 'Employee', '2020-09-04', 6),
						  ('August','Smith', '2000-10-12', 'Employee', '2021-06-07', 6)
SELECT	FirstName,
		LastName,
		DateOfBirth,
		[Role],
		CreatedDate,
		PharmacyId
FROM	[User]

--Table PaymentCode
CREATE TABLE PaymentCode
(
	PaymentCodeId	INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	PaymentCode		VARCHAR(20) NOT NULL,
	DeductionRate	DECIMAL(18, 2)
)
INSERT INTO PaymentCode VALUES ('BASICPAY', 0),
							   ('PF', 7.2),
							   ('PENSION', 3.9)
SELECT	PaymentCode,
		DeductionRate
FROM	PaymentCode
--Table Payslip
CREATE TABLE Payslip
(
	PayslipId		INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	PaymentCodeId	INT,
	CONSTRAINT		PaymentCodeId FOREIGN KEY (PaymentCodeId)
    REFERENCES		PaymentCode (PaymentCodeId),
	UserId			INT,
	CONSTRAINT		UserId FOREIGN KEY (UserId)
    REFERENCES		[User] (UserId)
)
INSERT INTO Payslip VALUES (1, 1), (2, 1), (3, 1),
						   (1, 2), (2, 2), (3, 2),
						   (1, 3), (2, 3), (3, 3),
						   (1, 4), (2, 4), (3, 4),
						   (1, 5), (2, 5), (3, 5),
						   (1, 6), (2, 6), (3, 6),
						   (1, 7), (2, 7), (3, 7),
						   (1, 8), (2, 8), (3, 8),
						   (1, 9), (2, 9), (3, 9),
						   (1, 10), (2, 10), (3, 10),
						   (1, 11), (2, 11), (3, 11),
						   (1, 12), (2, 12), (3, 12),
						   (1, 13), (2, 13), (3, 13),
						   (1, 14), (2, 14), (3, 14),
						   (1, 15), (2, 15), (3, 15),
						   (1, 16), (2, 16), (3, 16),
						   (1, 17), (2, 17), (3, 17),
						   (1, 18), (2, 18), (3, 18)
SELECT	PayslipId,
		PaymentCodeId,
		UserId
FROM	Payslip

--Table Salary
CREATE TABLE Salary
(
	SalaryId		INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	EmployeeId		INT,
	CONSTRAINT		EmployeeId FOREIGN KEY (EmployeeId)
    REFERENCES		[User] (UserId),
	GrossAmount		DECIMAL(18, 2),
	Deduction		DECIMAL(18, 2),
	NetAmount		DECIMAL(18, 2),
)
INSERT INTO Salary(EmployeeId, GrossAmount) VALUES (1, 350000),
															 (2, 320000),
															 (3, 325000),
															 (4, 360000),
															 (5, 330000),
															 (6, 325000),
															 (7, 360000),
															 (8, 325000),
															 (9, 326000),
															 (10, 365000),
															 (11, 340000),
															 (12, 342000),
															 (13, 370000),
															 (14, 325000),
															 (15, 320000),
															 (16, 400000),
															 (17, 370000),
															 (18, 350000)

-- Function to Calculate Deduction
CREATE FUNCTION [dbo].[CalculateDeduction]
(
	@userId		INT = 0
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
	DECLARE @gross DECIMAL(18, 2)
	SET @gross = (SELECT GrossAmount FROM Salary
				  WHERE EmployeeId = @userId)

	DECLARE @pf DECIMAL(18, 2)
	SET @pf = (SELECT payc.DeductionRate FROM PaymentCode AS payc INNER JOIN Payslip AS pays 
			   ON payc.PaymentCodeId = pays.PaymentCodeId
			   WHERE pays.PaymentCodeId = payc.PaymentCodeId AND pays.UserId = @userId AND payc.PaymentCode = 'PF')

	DECLARE @pension DECIMAL(18, 2)
	SET @pension = (SELECT payc.DeductionRate FROM PaymentCode AS payc INNER JOIN Payslip AS pays 
			   ON payc.PaymentCodeId = pays.PaymentCodeId
			   WHERE pays.PaymentCodeId = payc.PaymentCodeId AND pays.UserId = @userId AND payc.PaymentCode = 'PENSION')
	
	DECLARE @basicpay DECIMAL(18, 2)
	SET @basicpay = (SELECT payc.DeductionRate FROM PaymentCode AS payc INNER JOIN Payslip AS pays 
					 ON payc.PaymentCodeId = pays.PaymentCodeId
					 WHERE pays.PaymentCodeId = payc.PaymentCodeId AND pays.UserId = @userId AND payc.PaymentCode = 'BASICPAY')

	DECLARE @totalDeduction DECIMAL(18, 2)
	SET @totalDeduction = (@gross * (@pf / 100)) + (@gross * (@pension / 100) + (@gross * (@basicpay / 100))) 
	RETURN @totalDeduction
END

--store procedure to get details
CREATE PROCEDURE [dbo].[GetUserDetails]	
	@case	INT = 1
AS
BEGIN
	IF (@case = 1)
		BEGIN
			UPDATE	Salary
			SET		Deduction = (SELECT [dbo].[CalculateDeduction](EmployeeId)),
					NetAmount = GrossAmount - (SELECT [dbo].[CalculateDeduction](EmployeeId))
			WHERE	EmployeeId = EmployeeId 
			SELECT  EmployeeId,
					GrossAmount,
					Deduction,
					NetAmount
			FROM	Salary 
		END
	ELSE IF (@case = 2)
		BEGIN
			SELECT	[USE].Firstname AS UserName,
					[USE].[Role],
					PayC.PaymentCode
			FROM	Payslip AS PayS LEFT JOIN  PaymentCode AS PayC ON PayS.PaymentCodeId = PayC.PaymentCodeId
					LEFT JOIN [User] AS [USE] ON PayS.UserId = [USE].UserId
			WHERE	[USE].Role = 'Employee' AND [PayC].PaymentCode = 'BASICPAY'
		END
	ELSE IF (@case = 3)
		BEGIN
			SELECT		PHA.[Name] AS Pharmacy,
						MAX(SAL.NetAmount) AS HighestSalary
			FROM		[User] AS [USE] INNER JOIN Pharmacy AS PHA ON [USE].PharmacyId = PHA.PharmacyId 
						INNER JOIN Salary AS SAL ON [USE].UserId = SAL.EmployeeId
			WHERE		[USE].[Role] = 'Employee'
			GROUP BY	PHA.[Name]
		END	
END

EXECUTE GetUserDetails 1
EXECUTE GetUserDetails 2
EXECUTE GetUserDetails 3






