--drop tables if exists any
DROP TABLE IF EXISTS Student, Teacher, Department;
DROP TABLE IF EXISTS #Student, #Teacher, #Department;
--create table Department
CREATE TABLE Department
(
	DepartmentId	INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	[Name]			VARCHAR(50) NOT NULL,
	Contact			VARCHAR(20) NOT NULL,
	HOD				VARCHAR(50) NOT NULL,
	Capacity		INT			NOT NULL,
	Building		VARCHAR(20) NOT NULL
)
INSERT INTO Department VALUES('Computer Department', '+91-020-2562357', 'Dr. D. V. Medhane', 180, 'A-Building'),
							 ('IT Department', '+91-020-2562358', 'Dr. C. V. Jadhav', 90, 'A-Building'),
							 ('Mechanical Department', '+91-021-2574558', 'Dr. A. A. Andhare', 180, 'C-Building'),
							 ('Civil Department', '+91-021-2574554', 'Dr. P. M. Atre', 180, 'B-Building'),
							 ('ENTC Department', '+91-021-3454554', 'Dr. C. S. Patil', 90, 'C-Building' )
SELECT	[Name],
		Contact,
		HOD	,
		Capacity,
		Building
FROM	Department

--create table Teacher
CREATE TABLE Teacher
(
	TeacherId		INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	[Name]			VARCHAR(20) NOT NULL,
	Age				INT			NOT NULL,
	Gender			VARCHAR(20) NOT NULL,
	DateOfJoin		Date		NOT NULL,
	Contact			VARCHAR(20) NOT NULL,
	Salary			INT			NOT NULL,
	DepartmentId	INT			NOT NULL,
	CONSTRAINT		DepartmentId FOREIGN KEY (DepartmentId)
    REFERENCES		Department(DepartmentId)
)
INSERT INTO Teacher VALUES('Mr. G. H. Adke', 32, 'Male', '2000-09-04', '7209538976', 50000, 1),
						  ('Mrs. J. P. Patil', 30, 'Female', '2001-08-02', '9523558916', 45000, 4),
						  ('Mr. S. S. Gholap', 45, 'Male', '2001-09-02', '9422780969', 30000, 2),
						  ('Mrs. R. R. Shewale', 35, 'Female', '2000-02-02', '9529876544', 40000, 3),
						  ('Dr. D. V. Madhane', 36, 'Male', '1998-03-15', '9622875543', 100000, 1),
						  ('Mrs. G. H. Jadhav', 32, 'Female', '2000-09-04', '7275338976', 50000, 2),
						  ('Mrs. P. P. Kale', 31, 'Female', '2000-10-04', '9575338976', 40000, 2),
						  ('Mrs. J. P. Jagtap', 30, 'Female', '2001-08-12', '9673558916', 55000, 3),
						  ('Mr. J. P. Patil', 28, 'Male', '2001-08-02', '7523558916', 65000, 3),
						  ('Mrs. M. D. Mahale', 34, 'Female', '2001-08-02', '7523558916', 65000, 4),
						  ('Mr. S. H. Sanap', 32, 'Male', '2000-09-04', '7209538976', 50000, 5),
						  ('Mrs. M. D. Atre', 40, 'Female', '2001-08-02', '7523558916', 65000, 5),
						  ('Mr. A. R. Jadhav', 32, 'Male', '2000-09-04', '9275338976', 70000, 5)
SELECT	Tea.[Name],
		Tea.Age,
		Tea.Gender,
		Tea.DateOfJoin,
		Tea.Contact,
		Tea.Salary,
		Dep.[Name] AS Department
FROM	Teacher AS Tea LEFT JOIN Department AS DEP ON Tea.DepartmentId = Dep.DepartmentId

--crete table Student
CREATE TABLE Student
(
	StudentId		INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	[Name]			VARCHAR(50) NOT NULL,
	Age				INT			NOT NULL,
	Gender			VARCHAR(20) NOT NULL,
	Contact			VARCHAR(20) NOT NULL,
	DepartmentId	INT			NOT NULL,
	TeacherId		INT			NOT NULL, 
	CONSTRAINT		Dept FOREIGN KEY (DepartmentId)
    REFERENCES		Department(DepartmentId),
	CONSTRAINT		Mentor FOREIGN KEY (TeacherId)
    REFERENCES		Teacher(TeacherId)	
)
INSERT INTO Student VALUES('Apurva Jadhav', 21, 'Female', '7822289764', 1, 1),
						  ('Tanaya Gavande', 21, 'Female', '7239876544', 1, 5),
						  ('Rutuja Harale', 22, 'Female', '7289435788', 3, 4),
						  ('Krutika Rawal', 21, 'Female', '9522314467', 2, 3),
						  ('Aarti Sangle', 22, 'Female', '9522876459', 4, 2),
						  ('Piyush Atre', 20, 'Male', '9588965423', 4, 2),
						  ('Akshay Andhare', 22, 'Male', '8852796544', 5, 11),
						  ('Ishan patil', 21, 'Male', '9876342190', 5,12),
						  ('Pravin Jain', 20, 'Male', '9832457762', 5, 11),
						  ('Onkar Kulkarni', 22, 'Male', '9529878566', 5, 13),
						  ('Aditya Shinde', 22, 'Male', '8828649954', 5, 12)
SELECT	Stu.[Name],
		Stu.Age,
		Stu.Gender,
		Stu.Contact,
		Dep.[Name] As Department,
		Tea.[Name] AS Mentor
FROM	Student AS Stu
		LEFT JOIN Teacher AS Tea ON stu.TeacherId = Tea.TeacherId
		LEFT JOIN Department AS Dep ON stu.DepartmentId = Dep.DepartmentId

--Group By and Having clause
SELECT		SUM(Capacity) AS TotalCapacity,
			Building
FROM		Department
GROUP BY	Building

SELECT		AVG(Salary) AverageSalary,
			DepartmentId
FROM		Teacher
GROUP BY	DepartmentId
HAVING		AVG(Salary) > 30000

--Implement 3 temporary tables 
--1. Using #
CREATE TABLE #Department
(
	DepartmentId	INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	[Name]			VARCHAR(50) NOT NULL,
	Contact			VARCHAR(20) NOT NULL,
	HOD				VARCHAR(50) NOT NULL,
	Capacity		INT			NOT NULL,
	Building		VARCHAR(20) NOT NULL
)
INSERT INTO #Department VALUES('Computer Department', '+91-020-2562357', 'Dr. D. V. Medhane', 180, 'A-Building'),
							 ('IT Department', '+91-020-2562358', 'Dr. C. V. Jadhav', 90, 'A-Building'),
							 ('Mechanical Department', '+91-021-2574558', 'Dr. A. A. Andhare', 180, 'C-Building'),
							 ('Civil Department', '+91-021-2574554', 'Dr. P. M. Atre', 180, 'B-Building'),
							 ('ENTC Department', '+91-021-3454554', 'Dr. C. S. Patil', 90, 'C-Building' )
SELECT	[Name], 
		Contact,
		HOD,
		Capacity,
		Building
FROM	#Department

--2. Using SELECT
SELECT	T.[Name],
		T.Age,
		T.Gender,
		T.DateOfJoin,
		T.Contact,
		T.Salary,
		D.[Name] AS Department
INTO	#Teacher
FROM	Teacher AS T LEFT JOIN  Department AS D ON T.DepartmentId = D.DepartmentId

SELECT * FROM #Teacher

--3. Using   CTE - Find second highest salary of teacher from each department
;WITH CTE AS
(
	SELECT	ROW_NUMBER() OVER (PARTITION BY DepartmentId ORDER BY Salary DESC) AS RowNumber,
			[Name],
			Age,
			Gender,
			Salary,
			DepartmentId
	FROM	Teacher
)
SELECT		[Name],
			Age,
			Gender,
			Salary,
			DepartmentId
FROM		CTE
WHERE		RowNumber = 2

--Fetch All Teachers details with Department Name using INNER JOIN for all Departments.SELECT		T.[Name],			T.Age,			T.Gender,			T.Salary,			D.[Name]FROM		Teacher AS TINNER JOIN	Department AS DON			T.DepartmentId = D.DepartmentId--Fetch Teacher and Student details of last department using LEFT JOIN.SELECT		D.[Name] AS Department,			T.[Name] AS TeacherName,			S.[Name] AS StudentnameFROM		Student AS S 			LEFT JOIN Teacher AS T ON T.DepartmentId = S.DepartmentId AND T.TeacherId = S.TeacherId			LEFT JOIN Department AS D ON T.DepartmentId = D.DepartmentIdWHERE		D.DepartmentId = (SELECT MAX(DepartmentId) FROM Department)