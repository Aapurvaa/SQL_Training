
SET NOCOUNT ON;
-- Delete tables if exists
DROP TABLE IF EXISTS Hospital, Patient, Appointment

CREATE TABLE Hospital
(
	HospitalId INT NOT NULL,
	HospitalName VARCHAR(50) NOT NULL,
	HospitalAddress VARCHAR(100) NOT NULL,
	HospitalContact VARCHAR(20) NOT NULL,
	HospitalSpeciality VARCHAR(30) NOT NULL,
	HospitalCapacity INT NOT NULL,
	TotalWards INT NOT NULL,
	TotalPhysicians INT NOT NULL
)
INSERT INTO Hospital VALUES (1, 'VS Hospital','#815/306, Poonamalle Rd,Kilpauk,Chennai 600010.','91 44 4200 1000','trauma center',4000, 3, 14),
							(2, 'Apollo Hospital','Plot # 13, CBD Belapur,Maharashtra 400614.','91-253 2510 250','diabetes expert',10000, 7, 28),
							(3,'Medanta Hospital','CH Baktawar Rd, Sector 8, Haryana 122001.','0124 414 1414','cardiac specialist',15000, 9, 32),
							(4,'Fortis Hospital','1, 01 Level 1, Bannerghatta, Karnataka 560076.','91-124 4921021','trauma center',10000, 6, 26),
							(5,'Artemis Hospital','Sector 51, Gurugram, Haryana 122001.','91- 124 4588 888','child specialist',12000, 8, 27)
SELECT * FROM Hospital

CREATE TABLE Patient
(
	PatientId INT NOT NULL,
	PatientName VARCHAR(50) NOT NULL,
	PatientAge INT NOT NULL,
	PatientGender VARCHAR(10) NOT NULL,
	PatientContact VARCHAR(20) NOT NULL,
	ReferenceFrom VARCHAR(50) NOT NULL,
	PatientHistory VARCHAR(50) NOT NULL,
	IncuranceId VARCHAR(10) NOT NULL
)
INSERT INTO Patient VALUES (1, 'Connor Williams', 22, 'Male', '7122896543', 'Dr. Morgan', 'alcohol dependency', '5628 234-A'),
							(2, 'Julian Harris', 8, 'Female', '7299542099', 'Dr. Davis', 'asthma', '4562 623-C'),
							(3, 'Aidan Robinson', 42, 'Male','7186330966', 'Dr. Terry', 'anxiety', '7466 749-B'),
							(4, 'Harold Mitchell', 32, 'Female', '7234119745', 'Dr. Shelton', 'depression', '8765 876-D'),
							(5, 'Peter Morgan', 68, 'Male', '7233572967', 'Dr. Miles', 'diabetes', '4811 588-E')
SELECT * FROM Patient

CREATE TABLE Appointment 
(
	AppointmentId INT NOT NULL,
	PatientId INT NOT NULL,
	HospitalId INT NOT NULL,
	StartDateTime DATETIME NOT NULL,
	EndDateTime DATETIME NOT NULL,
	PhysicianId INT NOT NULL
)
INSERT INTO Appointment VALUES (5121, 1, 3, '2023-04-22 10:30:00', '2023-04-22 11:15:00', 1123),
								(5122, 2, 5, '2023-04-22 10:00:00.0', '2023-04-22 10:50:00.0', 1323),
								(5123, 3, 4, '2023-06-22 11:20:00.0', '2023-06-22 11:40:00.0', 4321 ),
								(5124, 4, 1, '2023-06-22 11:20:00.0', '2023-06-22 11:40:00.0', 7732),
								(5125, 5, 2, '2023-06-22 10:00:00.0', '2023-06-22 11:20:00.0', 7421)
SELECT * FROM Appointment

--Declare variable with different methods
DECLARE @Today DATETIME 
SET @Today = GETDATE()
PRINT @Today

DECLARE @Score DECIMAL(18,2) = '78687678.669';
PRINT @Score

DECLARE @Active BIT 
SELECT @Active = 1
PRINT @Active
